(() => {
  const FALLBACK = '/uploads/favicon.png';

  window.addEventListener('error', (event) => {
    const img = event.target;
    if (!(img instanceof HTMLImageElement)) return;
    if (img.dataset.fallbackApplied === '1') return;

    img.dataset.fallbackApplied = '1';
    img.src = FALLBACK;
    img.alt = img.alt || 'Imagem indisponível';
    img.style.objectFit = 'contain';
    img.style.padding = '12px';
  }, true);
})();
