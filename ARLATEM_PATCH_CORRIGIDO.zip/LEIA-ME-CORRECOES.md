# ARLATEM — patch corrigido

Este ZIP foi preparado para ser extraído **na raiz do projeto**, substituindo os arquivos existentes quando solicitado.

## Correções incluídas

- Todas as 12 páginas de categoria passam a carregar `/slug-utils.js?v=1` antes de `/catalogo.js?v=32`.
- CSS e JS das categorias foram padronizados na versão `v=32`.
- O script indevido `/cdn-cgi/challenge-platform/...` foi removido das páginas substituídas.
- Foi incluído `image-fallback.js`, que troca automaticamente imagens quebradas por um fallback.
- Foram adicionados links HTML estáticos entre as categorias para facilitar o rastreamento do Google.
- `catalogo.html` foi limpo e atualizado.
- `sitemap.xml` foi atualizado e inclui Home, catálogo e todas as categorias.
- Canonicals e URLs usam `https://www.arlatem.com.br/`.

## Depois do deploy

1. Abra algumas páginas e confirme que o catálogo carrega.
2. Confira no console do navegador se não aparece erro relacionado a `window.ArlaSlug`.
3. No Google Search Console, vá em **Indexação > Sitemaps** e envie/reenviar `sitemap.xml`.
4. Depois use **Inspeção de URL > Testar URL publicado** em uma categoria.
5. Se a URL estiver disponível para o Google, clique em **Solicitar indexação**.

## Observação importante sobre imagens

Este patch impede o ícone de imagem quebrada, mas se as URLs de imagens cadastradas no Supabase estiverem erradas ou apontarem para arquivos removidos, o ideal é corrigir essas URLs no banco também.
